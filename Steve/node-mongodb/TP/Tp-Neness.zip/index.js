db = connect('technocite');
var dbs = db.adminCommand('listDatabases');

//----------------------------exercice 2----------------------------------
//ne pas oublier de mettre les guillemets !!!!!!

//db.movies.copyTo('backUpMovies');
//printjson(dbs);

//----------------------------exercice 3.1--------------------------------

//var releaseMovies = db.movies.find(
//{},
//{_id : 0,'fields.title':1,'fields.release_date' : 1})
//.sort({ 'fields.release_date' : -1}
//).limit(10);

//releaseMovies.forEach( (result) => {
//   printjson(result);
//})

//----------------------------exercice 3.2-----------------------------------

//var alphaMovies = db.movies.find(
//{},
//{_id : 0,'fields.title':1})
//.sort(
//  { 'fields.title' : 1}
//).limit(10);

//alphaMovies.forEach( (result) => {
//  printjson(result);
//})


//exercice ---------------------------3.3------------------------------------

//var rankSort = db.movies
//.find(
        //{},
        //{_id : 0,'fields.title':1,'fields.rank':1})
//.sort(
        //{ 'fields.rank' : 1}
        //).limit(10);

//rankSort.forEach( (result) => {
// printjson(result);
// });

//exercice 4-----------------------------------------------------------

// 1)----------------------------------------------- 

// var actors = db.movies
//   .find(
//     { "fields.actors": { $in: ["Sharlto Copley"] } },
//     { "fields.title": 1, "fields.rank": 1, "fields.actors": 1 })
//   .limit(10);

// actors.forEach((result) => {
//   printjson(result);
// });



// 2)----------------------------------------------- 

// var gender = db.movies
//   .find(
//     { "fields.genres": { $in: ["Comedy"] } },
//     { "fields.title": 1, "fields.genres": 1 })
//   .limit(10);

// gender.forEach((result) => {
//   printjson(result);
// });

// 3)----------------------------------------------- 

// var between = db.movies
//   .find(
//     {
//       $and: [{ "fields.year": { $lt: 2008 } }, { "fields.year": { $gt: 2002 } }]
//     },
//     { "fields.title": 1, "fields.year": 1 })
//   .limit(10);

// between.forEach(result => {
//   printjson(result);
// });

// 4)----------------------------------------------- 

// var actors2 = db.movies
//   .find(
//     {
//       $and: [
//         { "fields.actors": { $in: ["Jennifer Lawrence"] } },
//         { "fields.actors": { $in: ["Matt Damon"] } }
//       ]
//     },
//     { "fields.title": 1, "fields.actors": 1 })
//   .limit(10);

// actors2.forEach(result => {
//   printjson(result);
// });

// 5)----------------------------------------------- 

// var actors3 = db.movies
//   .find(
//     {
//       $and: [
//         { "fields.actors": { $in: ["Sharlto Copley"] } },
//         { "fields.actors": { $in: ["Jodie Foster"] } }
//       ]
//     },
//     { "fields.title": 1, "fields.actors": 1 })
//   .limit(10);

// actors3.forEach(result => {
//   printjson(result);
// });

// 6)----------------------------------------------- 

// var directors = db.movies
//   .find(
//     {
//       $or: [
//         { "fields.directors": { $in: ["Brad Furman"] } },
//         { "fields.directors": { $in: ["Neil Burger"] } }
//       ]
//     },
//     { "fields.title": 1, "fields.directors": 1 })
//   .limit(10);

// directors.forEach(result => {
//   printjson(result);
// });

// 7)----------------------------------------------- 

// var year = db.movies
//   .find(
//     { "fields.year": { $exists: true } },
//     { "fields.title": 1, "fields.year": 1 }
//   )
//   .sort({ "fields.year": 1 })
//   .limit(1);

// year.forEach(result => {
//   printjson(result);
// });


//Exercice 5

// 1)----------------------------------------------- 

// var movies = db.movies.update(
//   { "fields.actors": { $in: ["Charlize Theron"] } },
//   {
//     $inc: { "fields.rank": 1000 }
//   },
//   { multi: true }
// );

// movies = db.movies
//   .find(
//     { "fields.actors": { $in: ["Charlize Theron"] } },
//     { "fields.title": 1, "fields.rank": 1, "fields.actors": 1 }
//   )
//   .limit(10);

// movies.forEach(movie => {
//   printjson(movie);
// });

// 2)-----------------------------------------------

// var movies = db.movies.remove(
//   { "fields.directors": { $in: ["Harald Zwart"] } },
//   { justOne: false }
// );

// movies = db.movies
//   .find(
//     { "fields.directors": { $in: ["Harald Zwart"] } },
//     { "fields.title": 1, "fields.directors": 1 }
//   )
//   .limit(10);

// movies.forEach(movie => {
//   printjson(movie);
// });


// 3)----------------------------------------------- 

// var movies = db.movies.update(
//   {
//     "fields.title": {
//       $in: ["+1", "3D rou pu tuan zhi ji le bao jian", "Anamorph"]
//     }
//   },
//   {
//     $push: { "fields.actors": "Key Key" }
//   },
//   { multi: true }
// );

// movies = db.movies
//   .find(
//     {
//       "fields.title": {
//         $in: ["+1", "3D rou pu tuan zhi ji le bao jian", "Anamorph"]
//       }
//     },
//     { "fields.title": 1, "fields.actors": 1 }
//   )
//   .limit(10);

// movies.forEach(movie => {
//   printjson(movie);
// });

//VILAAAAAAAAAAAAAAAAAAAA